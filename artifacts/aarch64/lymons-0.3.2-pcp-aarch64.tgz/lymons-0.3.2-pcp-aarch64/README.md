# LyMonS 0.3.2 for PiCorePlayer (aarch64)

Dynamic plugin-based OLED display driver for Logitech Media Server players.

**Architecture**: aarch64-unknown-linux-gnu
**Built for**: Raspberry Pi (TinyCore Linux / PiCorePlayer)

## Installation

1. Extract this package:
   ```bash
   tar xzf lymons-0.3.2-pcp-aarch64.tgz
   cd lymons-0.3.2-pcp-aarch64
   ```

2. Run installation script:
   ```bash
   sudo ./install.sh
   ```

3. Edit configuration:
   ```bash
   sudo nano /etc/lymons/lymons.yaml
   ```

4. Test:
   ```bash
   LyMonS
   ```

## Supported Displays

- **SSD1306** - 128x64 I2C (most common)
- **SSD1309** - 128x64 I2C
- **SH1106** - 132x64 I2C
- **SSD1322** - 256x64 SPI (grayscale)

## Plugin System

Drivers are loaded dynamically from:
- `/usr/local/lib/lymons/drivers/` (system-wide)
- `~/.local/lib/lymons/drivers/` (user-local)

Plugins are automatically discovered and loaded based on your `driver` setting in the config.

## Configuration

Example I2C configuration (SSD1306):
```yaml
display:
  driver: ssd1306
  bus:
    type: i2c
    bus: "/dev/i2c-1"
    address: 0x3C
  brightness: 128
```

Example SPI configuration (SSD1322):
```yaml
display:
  driver: ssd1322
  bus:
    type: spi
    bus: "/dev/spidev0.0"
    dc_pin: 24
    rst_pin: 25
```

## Autostart on PiCorePlayer

Add to `/opt/bootlocal.sh`:
```bash
/usr/local/bin/LyMonS &
```

## Files Included

- `usr/local/bin/LyMonS` - Main binary
- `usr/local/lib/lymons/drivers/*.so` - Plugin drivers (4 total)
- `etc/lymons/lymons.yaml.example` - Configuration template
- `install.sh` - Installation script

## License

GPL-3.0-or-later

## Version

0.3.2 (2026-03-02)
Built for: aarch64-unknown-linux-gnu
