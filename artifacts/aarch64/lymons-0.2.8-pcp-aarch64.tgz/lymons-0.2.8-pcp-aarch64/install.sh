#!/bin/sh
# LyMonS Installation Script for PiCorePlayer
# Run as: sudo ./install.sh

echo "Installing LyMonS for PiCorePlayer..."

# Copy files
cp -v usr/local/bin/LyMonS /usr/local/bin/
chmod +x /usr/local/bin/LyMonS

mkdir -p /usr/local/lib/lymons/drivers
cp -v usr/local/lib/lymons/drivers/*.so /usr/local/lib/lymons/drivers/

mkdir -p /etc/lymons
if [ ! -f /etc/lymons/lymons.yaml ]; then
    cp -v etc/lymons/lymons.yaml.example /etc/lymons/lymons.yaml
    echo "Created default configuration at /etc/lymons/lymons.yaml"
    echo "Please edit this file with your settings"
fi

# Make persistent on PiCorePlayer
if [ -f /usr/local/sbin/filetool.sh ]; then
    echo "/usr/local/bin/LyMonS" >> /opt/.filetool.lst
    echo "/usr/local/lib/lymons" >> /opt/.filetool.lst
    echo "/etc/lymons" >> /opt/.filetool.lst
    echo "Added to PiCorePlayer backup list"

    # Backup
    filetool.sh -b
    echo "Backup completed"
fi

echo "Installation complete!"
echo ""
echo "Next steps:"
echo "1. Edit /etc/lymons/lymons.yaml with your configuration"
echo "2. Run: LyMonS to test"
echo "3. Add to autostart if desired"
