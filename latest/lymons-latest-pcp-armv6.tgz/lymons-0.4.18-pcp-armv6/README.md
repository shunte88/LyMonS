# LyMonS 0.4.18 (armv6)

Dynamic OLED display driver for Logitech Media Server.

Works on **piCorePlayer (TinyCore Linux)** and **standard Raspberry Pi Linux**.
The installer detects your environment automatically.

## Installation

```bash
tar xzf lymons-0.4.18-pcp-armv6.tgz
cd lymons-0.4.18-pcp-armv6
sudo ./install.sh
```

That's it. The installer will:
- Detect piCorePlayer vs standard Linux
- Deploy the binary, drivers, and runtime assets to the correct locations
- Create a default configuration (edit before running)
- Generate a `gomonitor` launch script with paths pre-configured for your system
- On piCorePlayer: add to backup list and run `pcp bu` automatically

## Supported Displays

Color depth is a property of the driver, not the panel size.

| Driver        | Bus     | Color depth    | Panel sizes                                         |
|---------------|---------|----------------|-----------------------------------------------------|
| `ssd1306`     | I2C/SPI | Mono (1bpp)    | 128x64                                              |
| `ssd1309`     | I2C/SPI | Mono (1bpp)    | 128x64                                              |
| `sh1106`      | I2C/SPI | Mono (1bpp)    | 132x64                                              |
| `sh1107`      | I2C/SPI | Mono (1bpp)    | 128x128, 128x64                                     |
| `ssd1322`     | SPI     | Gray4 (4bpp)   | 256x64                                              |
| `sh1122`      | SPI     | Gray4 (4bpp)   | 256x64                                              |
| `st7789`      | SPI     | Rgb565 (16bpp) | 320x240, 320x170, 280x240, 240x240, 240x135, 160x80 |
| `st7796s`     | SPI     | Rgb565 (16bpp) | 480x320                                             |
| `sharpmemory` | SPI     | Mono (1bpp)    | 400x240                                             |

Set `width` and `height` in the `display:` block for the drivers that offer more
than one panel size. The rest fix their own size and ignore the values.

## Bus Interfaces

Enable the bus in the piCorePlayer web interface (Tweaks) and reboot, then run
the discovery helper to confirm the device nodes appeared:

```bash
<install dir>/show-buses.sh
```

It prints the I2C buses, SPI nodes and GPIO controllers the board exposes, the
line-numbering rule for the detected SoC, an `i2cdetect` scan of every bus and
any missing group membership.

- **I2C**: `/dev/i2c-1` on the 40-pin header, address usually 0x3C, sometimes 0x3D.
  The installer loads `i2c-tools.tcz` so `i2cdetect -y 1` is available to confirm
  the panel is answering.
- **SPI**: `/dev/spidev0.0` or `/dev/spidev0.1`, plus two GPIO lines for DC and
  reset. Pi header pins are BCM numbers, and the header GPIO controller is
  detected automatically, so `gpio_chip` is not needed on a Pi.

## piCorePlayer Autostart

Add via the piCorePlayer web interface (Tweaks → User Commands):
```
/mnt/mmcblk0p2/tce/lymons/gomonitor &
```

## Standard Pi Autostart

Add to `/etc/rc.local` before `exit 0`:
```bash
${HOME}/lymons/gomonitor &
```

## License

GPL-3.0-or-later. Version 0.4.18 (2026-11-16). Built for: arm-unknown-linux-gnueabihf
