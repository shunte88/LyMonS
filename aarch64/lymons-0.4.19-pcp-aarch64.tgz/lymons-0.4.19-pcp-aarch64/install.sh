#!/bin/sh
# LyMonS Universal Installer
# Detects piCorePlayer (TinyCore Linux) vs Debian/Raspberry Pi OS
# and deploys to the correct locations automatically.

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

echo "LyMonS Installer"
echo "================"

# Detect environment: check for pCP/TinyCore first, fall back to Debian/standard
detect_os() {
    # pCP: has pcp command, or /etc/issue mentions TinyCore/piCore
    if command -v pcp > /dev/null 2>&1 || \
       grep -qi "tinycore\|picore" /etc/issue 2>/dev/null; then
        echo "pcp"
        return
    fi
    # Debian / Raspberry Pi OS
    if grep -qi "debian\|raspbian\|ubuntu" /etc/os-release 2>/dev/null; then
        echo "linux"
        return
    fi
    # Unknown, so default to standard Linux behaviour
    echo "linux"
}

DEPLOY_MODE=$(detect_os)

if [ "${DEPLOY_MODE}" = "pcp" ]; then
    echo "Detected: piCorePlayer (TinyCore Linux)"
    RUNTIME_DIR="/mnt/mmcblk0p2/tce/lymons"
    BIN_DIR="${RUNTIME_DIR}"
    DRIVER_DIR="${RUNTIME_DIR}/drivers"
    CONFIG_DIR="${RUNTIME_DIR}/config"
else
    echo "Detected: Debian / Raspberry Pi OS"
    RUNTIME_DIR="${HOME}/lymons"
    BIN_DIR="/usr/local/bin"
    DRIVER_DIR="/usr/local/lib/lymons/drivers"
    CONFIG_DIR="${RUNTIME_DIR}/config"
fi

echo ""
echo "  Runtime : ${RUNTIME_DIR}"
echo "  Binary  : ${BIN_DIR}/LyMonS"
echo "  Drivers : ${DRIVER_DIR}"
echo "  Config  : ${CONFIG_DIR}/lymons.yaml"
echo ""

# Create directory structure
mkdir -p "${RUNTIME_DIR}/data" "${RUNTIME_DIR}/assets" "${RUNTIME_DIR}/fonts" \
         "${CONFIG_DIR}" "${DRIVER_DIR}"
[ "${DEPLOY_MODE}" = "linux" ] && mkdir -p "${BIN_DIR}"

# Deploy binary
cp "${SCRIPT_DIR}/bin/LyMonS" "${BIN_DIR}/LyMonS"
chmod +x "${BIN_DIR}/LyMonS"
echo "Installed binary: ${BIN_DIR}/LyMonS"

# Deploy drivers
if ls "${SCRIPT_DIR}/drivers/"*.so 1>/dev/null 2>&1; then
    cp "${SCRIPT_DIR}/drivers/"*.so "${DRIVER_DIR}/"
    echo "Installed drivers to ${DRIVER_DIR}/"
else
    echo "Warning: No driver plugins found in package"
fi

# Deploy runtime resources
cp -rf "${SCRIPT_DIR}/data/."   "${RUNTIME_DIR}/data/"
cp -rf "${SCRIPT_DIR}/assets/." "${RUNTIME_DIR}/assets/"
cp -rf "${SCRIPT_DIR}/fonts/."  "${RUNTIME_DIR}/fonts/"
cp -f  "${SCRIPT_DIR}/show-buses.sh" "${RUNTIME_DIR}/show-buses.sh"
chmod +x "${RUNTIME_DIR}/show-buses.sh"
echo "Installed runtime resources to ${RUNTIME_DIR}/"

# Deploy config: create from example if not already present, patch driver path
if [ ! -f "${CONFIG_DIR}/lymons.yaml" ]; then
    sed "s|folder: /DRIVER_DIR/|folder: ${DRIVER_DIR}/|" \
        "${SCRIPT_DIR}/config/lymons.yaml.example" > "${CONFIG_DIR}/lymons.yaml"
    echo "Created ${CONFIG_DIR}/lymons.yaml, please set your display driver and location"
else
    echo "Config exists, leaving ${CONFIG_DIR}/lymons.yaml unchanged"
fi

# Generate gomonitor with all paths resolved for this deployment
if [ "${DEPLOY_MODE}" = "pcp" ]; then
    cat > "${RUNTIME_DIR}/gomonitor" <<GOEOF
#!/bin/sh
# LyMonS for piCorePlayer - it's worth the squeeze
BINDIR="${RUNTIME_DIR}"

# Resolve player name from pCP config
PNAME=\$(grep "^NAME=" /usr/local/sbin/config.cfg 2>/dev/null | cut -d'"' -f2)

# Stop any running instance
killall LyMonS > /dev/null 2>&1; sleep 1
killall -9 LyMonS > /dev/null 2>&1

# Wait for squeezelite to be running before starting
echo "Waiting for squeezelite..."
until pidof squeezelite squeezelite-dsd > /dev/null 2>&1; do
    sleep 1
done
echo "Squeezelite running. Starting LyMonS${PNAME:+ for \${PNAME}}..."

# Ensure i2c is available
modprobe i2c_dev > /dev/null 2>&1
modprobe i2c-dev > /dev/null 2>&1

cd "\${BINDIR}" || {
    echo "Error: runtime folder \${BINDIR} not found."
    echo "LyMonS resolves assets, data and fonts relative to it."
    exit 1
}
exec sudo "\${BINDIR}/LyMonS" \
    \${PNAME:+--name "\${PNAME}"} \
    --config="${CONFIG_DIR}/lymons.yaml" \
    "\$@" > /dev/null 2>&1 &
GOEOF

else
    cat > "${RUNTIME_DIR}/gomonitor" <<GOEOF
#!/bin/sh
# LyMonS for Raspberry Pi - it's worth the squeeze
RUNTIME_DIR="${RUNTIME_DIR}"

# Stop any running instance
killall LyMonS > /dev/null 2>&1; sleep 1
killall -9 LyMonS > /dev/null 2>&1

# Wait for squeezelite (up to 30s), skip if not found
WAIT=0
while [ \$WAIT -lt 30 ]; do
    pidof squeezelite squeezelite-dsd > /dev/null 2>&1 && break
    sleep 1
    WAIT=\$((WAIT + 1))
done

cd "\${RUNTIME_DIR}" || {
    echo "Error: runtime folder \${RUNTIME_DIR} not found."
    echo "LyMonS resolves assets, data and fonts relative to it."
    exit 1
}
exec sudo LyMonS \
    --config="${CONFIG_DIR}/lymons.yaml" \
    "\$@" > /dev/null 2>&1 &
GOEOF

fi
chmod +x "${RUNTIME_DIR}/gomonitor"
echo "Generated ${RUNTIME_DIR}/gomonitor"

# Platform-specific post-install
if [ "${DEPLOY_MODE}" = "pcp" ]; then
    # Load i2c tools extension
    tce-load -i i2c-tools.tcz 2>/dev/null || true
    # Register with pCP backup so it survives reboots
    if [ -f /usr/local/sbin/filetool.sh ]; then
        grep -v "^${RUNTIME_DIR}" /opt/.filetool.lst > /tmp/.filetool.lst.tmp \
            && mv /tmp/.filetool.lst.tmp /opt/.filetool.lst
        echo "${RUNTIME_DIR}" >> /opt/.filetool.lst
        pcp bu
        echo "Registered with piCorePlayer backup"
    fi
    echo ""
    echo "Installation complete!"
    echo ""
    echo "  Show buses  : ${RUNTIME_DIR}/show-buses.sh"
    echo "  Edit config : ${CONFIG_DIR}/lymons.yaml"
    echo "  Test        : ${RUNTIME_DIR}/gomonitor"
    echo "  Autostart   : add via piCorePlayer web interface > Tweaks > User Commands:"
    echo "                ${RUNTIME_DIR}/gomonitor &"
else
    echo ""
    echo "Installation complete!"
    echo ""
    echo "  Show buses  : ${RUNTIME_DIR}/show-buses.sh"
    echo "  Edit config : ${CONFIG_DIR}/lymons.yaml"
    echo "  Test        : ${RUNTIME_DIR}/gomonitor"
    echo "  Autostart   : add to /etc/rc.local before 'exit 0':"
    echo "                ${RUNTIME_DIR}/gomonitor &"
fi
