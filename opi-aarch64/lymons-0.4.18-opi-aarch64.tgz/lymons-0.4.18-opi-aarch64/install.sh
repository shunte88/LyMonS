#!/bin/sh
# LyMonS Orange Pi Installer (Armbian / Debian / Ubuntu)

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

echo "LyMonS Installer for Orange Pi"
echo "============================"

RUNTIME_DIR="${HOME}/lymons"
BIN_DIR="/usr/local/bin"
DRIVER_DIR="/usr/local/lib/lymons/drivers"
CONFIG_DIR="${RUNTIME_DIR}/config"

echo ""
echo "  Runtime : ${RUNTIME_DIR}"
echo "  Binary  : ${BIN_DIR}/LyMonS"
echo "  Drivers : ${DRIVER_DIR}"
echo "  Config  : ${CONFIG_DIR}/lymons.yaml"
echo ""

mkdir -p "${RUNTIME_DIR}/data" "${RUNTIME_DIR}/assets" "${RUNTIME_DIR}/fonts" \
         "${CONFIG_DIR}" "${DRIVER_DIR}" "${BIN_DIR}"

# Deploy binary
cp "${SCRIPT_DIR}/bin/LyMonS" "${BIN_DIR}/LyMonS"
chmod +x "${BIN_DIR}/LyMonS"
echo "Installed binary: ${BIN_DIR}/LyMonS"

# Deploy drivers
if ls "${SCRIPT_DIR}/drivers/"*.so 1>/dev/null 2>&1; then
    cp "${SCRIPT_DIR}/drivers/"*.so "${DRIVER_DIR}/"
    echo "Installed drivers to ${DRIVER_DIR}/"
else
    echo "Warning: No driver plugins found in package"
fi

# Deploy runtime resources
cp -rf "${SCRIPT_DIR}/data/."   "${RUNTIME_DIR}/data/"
cp -rf "${SCRIPT_DIR}/assets/." "${RUNTIME_DIR}/assets/"
cp -rf "${SCRIPT_DIR}/fonts/."  "${RUNTIME_DIR}/fonts/"
cp -f  "${SCRIPT_DIR}/show-buses.sh" "${RUNTIME_DIR}/show-buses.sh"
chmod +x "${RUNTIME_DIR}/show-buses.sh"
echo "Installed runtime resources to ${RUNTIME_DIR}/"

# Deploy config: create from example if not already present, patch driver path
if [ ! -f "${CONFIG_DIR}/lymons.yaml" ]; then
    sed "s|folder: /DRIVER_DIR/|folder: ${DRIVER_DIR}/|" \
        "${SCRIPT_DIR}/config/lymons.yaml.example" > "${CONFIG_DIR}/lymons.yaml"
    echo "Created ${CONFIG_DIR}/lymons.yaml, set your display bus and location"
else
    echo "Config exists, leaving ${CONFIG_DIR}/lymons.yaml unchanged"
fi

# Launch script
cat > "${RUNTIME_DIR}/gomonitor" <<GOEOF
#!/bin/sh
# LyMonS for Orange Pi - it's worth the squeeze
RUNTIME_DIR="${RUNTIME_DIR}"

# Stop any running instance
killall LyMonS > /dev/null 2>&1; sleep 1
killall -9 LyMonS > /dev/null 2>&1

# Wait for squeezelite (up to 30s), skip if not found
WAIT=0
while [ \$WAIT -lt 30 ]; do
    pidof squeezelite squeezelite-dsd > /dev/null 2>&1 && break
    sleep 1
    WAIT=\$((WAIT + 1))
done

cd "\${RUNTIME_DIR}" || {
    echo "Error: runtime folder \${RUNTIME_DIR} not found."
    echo "LyMonS resolves assets, data and fonts relative to it."
    exit 1
}
exec sudo LyMonS \
    --config="${CONFIG_DIR}/lymons.yaml" \
    "\$@" > /dev/null 2>&1 &
GOEOF
chmod +x "${RUNTIME_DIR}/gomonitor"
echo "Generated ${RUNTIME_DIR}/gomonitor"

# Make sure the character devices are reachable
modprobe i2c-dev > /dev/null 2>&1
for grp in i2c spi gpio; do
    getent group "${grp}" > /dev/null 2>&1 && adduser "${SUDO_USER:-$USER}" "${grp}" > /dev/null 2>&1
done

echo ""
echo "Installation complete!"
echo ""
echo "  1. Enable the buses you need in /boot/armbianEnv.txt, e.g.:"
echo "       overlays=i2c5-m3 spi4-m0-cs1-spidev"
echo "     (armbian-config > System > Hardware lists the overlays for your board)"
echo "     then reboot."
echo "  2. See what the board exposes : ${RUNTIME_DIR}/show-buses.sh"
echo "  3. Edit config                : ${CONFIG_DIR}/lymons.yaml"
echo "  4. Test                       : ${RUNTIME_DIR}/gomonitor"
echo "  5. Autostart                  : add to /etc/rc.local before 'exit 0':"
echo "                                  ${RUNTIME_DIR}/gomonitor &"
