# LyMonS 0.4.19 for Orange Pi (aarch64)

Dynamic OLED display driver for Lyrion Media Server.

Built for the current 64-bit Orange Pi boards, Rockchip and Allwinner alike,
running Armbian, Debian or Ubuntu:

| Board                                           | SoC              | GPIO layout |
|-------------------------------------------------|------------------|-------------|
| Orange Pi 5 / 5B / 5 Plus / 5 Pro / 5 Max / CM5 | RK3588 / RK3588S | Rockchip    |
| Orange Pi 3B                                    | RK3566           | Rockchip    |
| Orange Pi 4 / 4 LTS                             | RK3399           | Rockchip    |
| Orange Pi Zero 3 / Zero 2W                      | Allwinner H618   | Allwinner   |

Only the older 32-bit Allwinner boards (Zero / Zero LTS on H2+/H3, PC, PC Plus,
One) fall outside this package. They run the `armv7` Raspberry Pi package
instead: the binary is architecture-compatible, and only the bus and GPIO
configuration differs, exactly as described below.

## Installation

```bash
tar xzf lymons-0.4.19-opi-aarch64.tgz
cd lymons-0.4.19-opi-aarch64
sudo ./install.sh
```

## Board setup (do this first)

Orange Pi does not use `raspi-config` or `/boot/config.txt`.  Enable the I2C or
SPI overlay for your board in `/boot/armbianEnv.txt`. Under `armbian-config`,
System then Hardware lists what is available. Reboot afterwards:

```
overlays=i2c5-m3 spi4-m0-cs1-spidev
```

Then run `./show-buses.sh` to see the resulting `/dev/i2c-*`, `/dev/spidev*`
and GPIO controllers, and put those into `lymons.yaml`.

## GPIO pins are not BCM numbers

On a Raspberry Pi the whole 40-pin header is one GPIO controller whose line
offsets happen to be the BCM numbers, so `dc_pin: 24` means BCM 24.

**Rockchip** registers one controller per bank, `gpio0` through `gpio4` with 32
lines each, so you must name the bank and give a bank-relative line:

```
line = group * 8 + index        (group A=0, B=1, C=2, D=3)
PC7  = 2 * 8 + 7 = 23           on bank 3
```

**Allwinner** (Zero 3 / Zero 2W) uses two controllers instead, the main pinctrl
and the R_PIO that carries the PL bank, with a flat number inside each:

```
line = bank * 32 + index        (bank A=0, B=1, C=2 ... I=8)
PC7  = 2 * 32 + 7 = 71          on the main pinctrl
PL10 = 10                       on the R_PIO controller
```

Run `./show-buses.sh` for the exact controller labels on your board. They are
device-tree node names such as `gpio3` (Rockchip) or `300b000.pinctrl`
(Allwinner), and `gpio_chip` accepts either the label or the `/dev/gpiochipN`
path.

```yaml
bus:
  type: spi
  bus: "/dev/spidev4.0"
  gpio_chip: "gpio3"    # bank, also accepts "/dev/gpiochip3" or "3"
  dc_pin: 23            # bank-relative line
  rst_pin: 24
```

Plugin drivers do not read the YAML config; set `LYMONS_GPIO_CHIP=gpio3` in the
environment for those.

## Supported Displays

Color depth is a property of the driver, not the panel size.

| Driver        | Bus     | Color depth    | Panel sizes                                         |
|---------------|---------|----------------|-----------------------------------------------------|
| `ssd1306`     | I2C/SPI | Mono (1bpp)    | 128x64                                              |
| `ssd1309`     | I2C/SPI | Mono (1bpp)    | 128x64                                              |
| `sh1106`      | I2C/SPI | Mono (1bpp)    | 132x64                                              |
| `sh1107`      | I2C/SPI | Mono (1bpp)    | 128x128, 128x64                                     |
| `ssd1322`     | SPI     | Gray4 (4bpp)   | 256x64                                              |
| `sh1122`      | SPI     | Gray4 (4bpp)   | 256x64                                              |
| `st7789`      | SPI     | Rgb565 (16bpp) | 320x240, 320x170, 280x240, 240x240, 240x135, 160x80 |
| `st7796s`     | SPI     | Rgb565 (16bpp) | 480x320                                             |
| `sharpmemory` | SPI     | Mono (1bpp)    | 400x240                                             |

Set `width` and `height` in the `display:` block for the drivers that offer more
than one panel size. The rest fix their own size and ignore the values.

I2C panels need only `bus` and `address`. SPI panels additionally need `dc_pin`,
usually `rst_pin`, and on this board family `gpio_chip` as described above.

## Autostart

Add to `/etc/rc.local` before `exit 0`:
```bash
${HOME}/lymons/gomonitor &
```

## License

GPL-3.0-or-later. Version 0.4.19 (2026-11-20). Built for: aarch64-unknown-linux-gnu
